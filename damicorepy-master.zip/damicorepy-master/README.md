# DAMICORE-PY - A PYTHON IMPLEMENTATION OF DAMICORE.

 
 DAMICORE is an unsupervised machine learning method combining techniques from
 information theory,  phylogenetics and Complex Network.  
 
 Damicore-Py is an alternative implementation written in Python.


