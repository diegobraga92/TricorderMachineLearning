import glob
import os
import collections

def get_results(path):
    r = {}
    tfiles = glob.glob(path + '/*worked1')
    for f in tfiles:
        names = os.path.basename(f).split('_')
        w = names[0]
        num = int(names[1].split('.')[0])
        if w in r:
            if num < r[w]:
                r[w] = num
        else:
            r[w] = num
    return r


def show_results(path):
    print('-------------------------------------------------------')
    print(os.path.basename(path))
    print('-------------------------------------------------------')
    r = get_results(path)
    for k,v in collections.OrderedDict(sorted(r.items())).items():
        print(k+':'+str(v))
    print('-------------------------------------------------------')


show_results('/home/diego/datalab/measurements/workspace/data_csv')
show_results('/home/vitor/python/measurements/e_workspace/yatServer')